import re
import random
import string
import difflib
import numpy as np
import pandas as pd
from django.urls import reverse
from pdata.models import pdata2
from django.conf import settings
from mydata.models import mydata3,ContactMessage
from django.utils import timezone
from django.contrib import messages
from django.utils.timezone import now
from django.core.mail import send_mail
from django.db.models import Max, Count
from datetime import timedelta, datetime
from sklearn.metrics.pairwise import cosine_similarity
from django.http import HttpResponse, HttpResponseRedirect
from sklearn.feature_extraction.text import TfidfVectorizer
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout



@csrf_protect
def delete_product2(request):
    if request.method == "POST":
        pid = request.POST.get('pid')
        product = get_object_or_404(pdata2, pid=pid)
        product.delete()
        messages.success(request, 'Product deleted successfully.')
        return redirect('all_products')  # Redirect to the homepage or the relevant page
    return redirect('all_products')  # Redirect to the homepage if the method is not POST


@csrf_protect
def delete_product(request):
    if request.method == "POST":
        pid = request.POST.get('pid')
        product = get_object_or_404(pdata2, pid=pid)
        product.delete()
        messages.success(request, 'Product deleted successfully.')
        return redirect('viewproduct')  # Redirect to the homepage or the relevant page
    return redirect('viewproduct')  # Redirect to the homepage if the method is not POST

def index(request):
    if request.method == "POST":
        name = request.POST['name']
        username = request.POST['username']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        
        # Password strength validation
        password_pattern = re.compile(r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$')
        
        if mydata3.objects.filter(username=username).exists():
            messages.error(request, "Email already exists. Please choose a different Email.")
        elif pass1 != pass2:
            messages.error(request, "Password and Confirm Password do not match!")
        elif not password_pattern.match(pass1):
            messages.error(request, "Please enter a stronger password. It must be at least 8 characters long, include uppercase and lowercase letters, a number, and a special character.")
        else:
            otp = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
            # Store OTP in session
            request.session['otp1'] = otp
            request.session['otp_expiry'] = (timezone.now() + timedelta(minutes=10)).isoformat()
            
            # Store registration details in session
            request.session['registration_data'] = {
                'name': name,
                'username': username,
                'pass1': pass1,
                'pass2': pass2
            }
            
            try:
                send_mail(
                    'Smart Shop',
                    f'Your OTP code is: {otp}',
                    'aniketkangude9060@gmail.com',
                    [username],
                    fail_silently=False,
                )
                # messages.success(request, "Please check your email for the OTP.")
                return redirect('otp')  # Redirect to OTP verification page
            except Exception as e:
                messages.error(request, f'There was an error sending your OTP: {str(e)}')

    return render(request, "index.html")


def otp(request):
    if request.method == "POST":
        entered_otp = request.POST.get('otp')
        session_otp = request.session.get('otp1')
        otp_expiry_str = request.session.get('otp_expiry')
        otp_expiry = datetime.fromisoformat(otp_expiry_str) if otp_expiry_str else None

        if not session_otp or not otp_expiry:
            messages.error(request, "OTP has expired or is not available.")
            return redirect('index')
        
        if timezone.now() > otp_expiry:
            messages.error(request, "OTP has expired. Please request a new OTP.")
            return redirect('index')

        if entered_otp == session_otp:
            # Retrieve registration details from session
            registration_data = request.session.get('registration_data')
            if registration_data:
                User_ID = request.session.get('user_id')
                name = registration_data['name']
                username = registration_data['username']
                pass1 = registration_data['pass1']
                pass2 = registration_data['pass2']
                
                hashed_password1 = make_password(pass1)
                hashed_password2 = make_password(pass2)
                
                # Save user data to the database
                data = mydata3(name=name, username=username, pass1=hashed_password1, pass2=hashed_password2)
                data.save()
                 
                # Clear session data
                request.session.pop('otp1', None)
                request.session.pop('otp_expiry', None)
                request.session.pop('registration_data', None)
                
                messages.success(request, "OTP verified successfully!")
                return redirect('home')
            else:
                messages.error(request, "Registration data is missing.")
                return redirect('index')
        else:
            messages.error(request, "Invalid OTP. Please try again.")
    
    return render(request, 'otp.html')



def login(request):
    if request.method == "POST":
        username = request.POST['uname']
        password = request.POST['password']

        # Check if the login is for the admin user
        if username == "admin" and password == "Admin@123":
            request.session['user_id'] = "admin"
            request.session['admin'] = 1  # Set admin flag
            messages.success(request, "Admin login successful!")
            return redirect('home')  # Redirect to the home page or admin dashboard
        
        try:
            # Authenticate normal users
            user = mydata3.objects.get(username=username)
            if check_password(password, user.pass1):  # Verify password hash
                request.session['user_id'] = user.id
                request.session['admin'] = 0  # Normal user flag
                messages.success(request, "Login successful!")
                return redirect('home')  # Assuming you have a URL name 'home'
            else:
                messages.error(request, "Invalid login details")
        except mydata3.DoesNotExist:
            messages.error(request, "User does not exist")
    
    return render(request, "login.html")


@csrf_protect
def home(request):
    if 'user_id' not in request.session:
        return redirect('login')
    
    user_id = request.session.get('user_id')  # Get user ID from session
    pdata = pdata2.objects.all()

    data2 = {
        'pdata': pdata,
        'user_id': user_id,  # Pass user_id to the template
    }

    return render(request, "home.html", data2)


def about(request):
        if 'user_id' not in request.session:
                return redirect('login')
        return render(request, "about.html")


# def contactus(request):
        
#         if 'user_id' not in request.session:
#                 return redirect('login')
        
#         if request.method == 'POST':
#             name = request.POST.get('name', '')
#             email = request.POST.get('email', '')
#             subject = request.POST.get('subject', '')
#             message = request.POST.get('message', '')
#             try:  
#                 send_mail(
#                         subject,
#                         message,
#                         'aniketkangude9060@gmail.com',
#                         [email],
#                         fail_silently=False,
#                 )
#                 messages.success(request, 'Your message has been sent successfully.')
#             except Exception as e:
#                 messages.error(request, f'There was an error sending your message: {str(e)}')
#         return render(request, "contactus.html")


def contactus(request):
    if 'user_id' not in request.session:
        return redirect('login')
        
    if request.method == 'POST':
        user_id = request.session.get('user_id')
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        subject = request.POST.get('subject', '')
        message = request.POST.get('message', '')
    
        msg=ContactMessage(user_id=user_id,name=name,email=email,subject=subject,message=message)
        msg.save()
        messages.success(request, "Message Send successfully!")
    return render(request,"contactus.html")

def addproduct(request):
        if 'user_id' not in request.session:
                return redirect('login')
        else:
                if request.method == "POST" and request.FILES['photo']:
                        oname = request.POST['oname']
                        pname = request.POST['pname']
                        page = request.POST['page']
                        op = request.POST['op']
                        sp = request.POST['sp']
                        pd = request.POST['pd']
                        address = request.POST['address']
                        image = request.FILES['photo']
                        id=request.session.get('user_id')
                        pid=request.session.get('id')               
                                       
                        data2 = pdata2(oname=oname, pname=pname, page=page, op=op, sp=sp, pd=pd, address=address, image=image,uid=id,pid=pid)
                        data2.save()
                        messages.success(request, 'Product added successfully.')
                return render(request, 'addproduct.html')

def profile(request):
    user_id = request.session.get('user_id')
    # print(f"User ID from session: {user_id}")  # Debugging line
    if user_id:
        try:
            user_id = int(user_id)  # Ensure the user_id is an integer
            user = mydata3.objects.filter(id=user_id).first()
            if user:
                data = {
                    'user': user
                }
                return render(request, "profile.html", data)
            else:
                return redirect('login')  # Redirect to login page if user_id is invalid
        except ValueError:
            return redirect('login')  # Handle case if user_id is not a valid integer
    else:
        return redirect('login')  # Redirect to login page if no user_id in session

    
def viewproduct(request):
        user_id = request.session.get('user_id')
        # print(user_id)

        if user_id:
            product=pdata2.objects.filter(uid=user_id)
            data={
                          'product':product
                    }
            return render(request,'viewproduct.html',data)
           
        else:
              return redirect('login')                    

def logout(request):
    request.session.flush()
    # request.cookies.clear()
    messages.success(request, "logout successful!")
    
    return redirect("login")


def product_detail(request, pk):  # Ensure 'pk' is received
    product = get_object_or_404(pdata2, pid=pk)  # Fetch product using 'pk'
    
    return render(request, "product_detail.html", {"product": product})



@csrf_protect
def pclick(request):
    if request.method == "POST":
        user_id = request.session.get('user_id')  # Get user_id from session
        pid = request.POST.get('pid')  # Get clicked product ID
        pname = request.POST.get('pname')  # Get product name

        # Set a cookie for the last clicked product
        response = redirect(reverse('product_detail', args=[pid]))
        response.set_cookie('last_clicked_product', pid, max_age=315360000, samesite='Lax')  # Store for 1 day
        
        return response
    
    
    
def rp_products(request):
    user_id = request.session.get('user_id')  # Get user ID from session
    products = pdata2.objects.all()  # Get all products

    # print("User ID: ", user_id)

    # Get last-clicked product from cookies for the specific user
    last_clicked_pid = request.COOKIES.get(f"last_clicked_product_{user_id}")  # Get last-clicked product from cookies
    # print("Last Clicked Product ID from Cookies:", last_clicked_pid)

    recommended_products = []

    if last_clicked_pid:
        try:
            last_clicked_pid = int(last_clicked_pid)  # Convert to integer
            last_product = pdata2.objects.get(pid=last_clicked_pid)

            # Use only 'pname' for similarity (assuming 'description' is missing)
            all_products = list(pdata2.objects.all())
            product_texts = [p.pname for p in all_products]  

            # TF-IDF Vectorization for product names
            vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2), min_df=1, max_df=0.85)
            tfidf_matrix = vectorizer.fit_transform(product_texts)

            last_product_index = next(i for i, p in enumerate(all_products) if p.pid == last_clicked_pid)

            # Compute cosine similarity
            cosine_sim = cosine_similarity(tfidf_matrix[last_product_index], tfidf_matrix).flatten()

            # Get top 2 similar products (excluding the last-clicked product)
            similar_indices = np.argsort(cosine_sim)[::-1][1:3]  
            recommended_products = [all_products[i] for i in similar_indices if all_products[i].pid != last_product.pid]

        except (pdata2.DoesNotExist, ValueError) as e:
            print(f"Error: {e}")  

    # Cold start: Recommend top-selling products if no recommendations found
    if not recommended_products:
        recommended_products = pdata2.objects.annotate(num_views=Count('pid')).order_by('-num_views')[:5]

    return render(request, "rp_products.html", {
        "products": products,
        "recommended": recommended_products
    })



def all_products(request):
    # Check if the user is logged in
    if 'user_id' not in request.session:
        return redirect('login')
    
    # Fetch all product data
    pdata = pdata2.objects.all()
    data2 = {
        'pdata': pdata
    }
    
    # Render the template with the product data
    return render(request, 'all_products.html', data2)


def all_users(request):
    if 'user_id' not in request.session or request.session.get('admin') != 1:
        return redirect('login')  # Redirect non-admin users to the login page
    
    # Fetch all users except the one with username "admin"
    users = mydata3.objects.exclude(username="admin")
    user_count = users.count()  # Get the count of users
    
    return render(request, 'all_users.html', {'users': users, 'user_count': user_count})


def delete_user(request, user_id):
    # Get the user object or return a 404 error if not found
    user = get_object_or_404(mydata3, id=user_id)  # Corrected line
    
    if request.method == "POST":  # Confirm deletion for security
        user.delete()  # Delete the user object
        messages.success(request, "User deleted successfully.")
        
        return redirect('all_users')  # Redirect to the user list page

    messages.error(request, "Invalid request.")
    return redirect('all_users')


def admin_panel(request):
    if 'user_id' not in request.session or request.session.get('admin') != 1:
        return redirect('login')
    return render(request,'admin_panel.html') 


def user_product(request, user_id):
    # Get the user by ID
    users = get_object_or_404(mydata3, id=user_id)
    
    # Fetch products associated with the user
    products = pdata2.objects.filter(uid=user_id)  # Replace 'uid' with the correct field name
    users = mydata3.objects.filter(id=user_id)  # Replace 'uid' with the correct field name
    
    # Render the template with the user and their products
    return render(request, 'user_product.html', {'users': users, 'products': products})



import matplotlib.pyplot as plt
import io
import base64


def selling_price(request):
    # Fetch selling prices from pdata2
    products = pdata2.objects.all()
    selling_prices = [product.sp for product in products]

    # Categorize prices into different ranges
    range_0_9999 = len([price for price in selling_prices if 0 <= price < 10000])
    range_10000_19999 = len([price for price in selling_prices if 10000 <= price < 20000])
    range_20000_29999 = len([price for price in selling_prices if 20000 <= price < 30000])
    range_30000_39999 = len([price for price in selling_prices if 30000 <= price < 40000])
    range_40000_above = len([price for price in selling_prices if price >= 40000])

    # Data for the graph
    categories = ['0 - 9999', '10000 - 19999', '20000 - 29999', '30000 - 39999', '40000+']
    values = [range_0_9999, range_10000_19999, range_20000_29999, range_30000_39999, range_40000_above]
    colors = ['#ff5733', '#33c1ff', '#9bff33', '#f9d200', '#ff33a1']  # Custom colors for the bars

    # Create the bar graph
    plt.figure(figsize=(8, 6))
    plt.bar(categories, values, color=colors)
    plt.xlabel('Price Range')
    plt.ylabel('Number of Products')
    plt.title('Selling Price Distribution')
    
    # Save the plot to a BytesIO object and encode it to base64
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    graph_data = base64.b64encode(img.getvalue()).decode('utf-8')
    
    # Pass the graph to the template
    return render(request, 'selling_price.html', {'graph_data': graph_data})
