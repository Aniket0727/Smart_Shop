from django.apps import AppConfig


class PdataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pdata'
