from django.contrib import admin
from mydata.models import mydata3,ContactMessage
# Register your models here.

class data(admin.ModelAdmin):
    list_display=('id','name','username','pass1','pass2')
  
admin.site.register(mydata3,data)

@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('id', 'user_id', 'name', 'email', 'subject', 'message', 'created_at')  # Fields to display
    search_fields = ('name', 'email', 'subject')  # Search functionality
    list_filter = ('created_at',)  # Filter by date